NOTE! Before you run the installation, you must extract the entire
ZIP file to a temporary directory. Just double-clicking on the 
MSI files inside the ZIP will NOT work.

Before you begin, please read the installation instructions at
http://pginstaller.projects.postgresql.org
Also see the FAQ available at
http://wiki.postgresql.org/wiki/Running_%26_Installing_PostgreSQL_On_Native_Windows

The files postgresql-8.3.msi and postgresql-8.3-int.msi contain 
PostgreSQL version 8.3.12. The reason for naming the files 8.3
is because the method used to upgrade the installation does not
permit the filename to be changed.

If you need to add or remove a feature afer you have upgraded, 
you must use the this version of the MSI file.
